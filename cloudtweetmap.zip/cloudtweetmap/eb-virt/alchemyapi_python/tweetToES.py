from elasticsearch import Elasticsearch
import tweepy
import time
import boto
import boto.sqs
from alchemyapi import AlchemyAPI
from boto.sqs.message import Message
from alchemyapi import AlchemyAPI
import boto.sqs
import boto.sns
import json

# Retrieve tweet text, id, coordinates, user, user id, time, number of re-tweet, number of liked

consumer_key = 'xxx'
consumer_secret = 'xxx'
access_token = 'xxx'
access_token_secret = 'Dxxxxx'


conn = boto.sqs.connect_to_region("us-west-2", aws_access_key_id='xxx', aws_secret_access_key='xxxx')
my_queue = conn.get_queue('sqsqueue')
sns = boto.sns.connect_to_region('us-west-2')
topic="arn:aws:sns:us-west-2:838801113820:filtertweets"
subject="Sentiment"
alchemyapi = AlchemyAPI()


auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)

# Authentication
api = tweepy.API(auth)

# Add location
places = api.geo_search(query="United States", granularity="country")
place_id = places[0].id

es = Elasticsearch()
# Obtain the tweets and store into the ES

# Download 100 tweets

counter = 0
while counter < 5000:
    tweets = api.search(q="place:%s" % place_id, count = 100)
    for tweet in tweets:

        if not tweet.coordinates:
            continue

        tweet_dict = {}
        tweet_dict['id'] = tweet.id
        tweet_dict['text'] = tweet.text
        tweet_dict['user-name'] = tweet.user.name
        tweet_dict['user-id'] = tweet.user.id
        tweet_dict['hashtag'] = [ht['text'] for ht in tweet.entities['hashtags']]
        tweet_dict['coordinates'] = tweet.coordinates['coordinates']
        tweet_dict['place'] = ''
        tweet_dict['created-at'] = ''
        tweet_dict['retweet-count'] = tweet.retweet_count
        tweet_dict['favorite-count'] = tweet.favorite_count

        if tweet.place:
			tweet_dict['place'] = tweet.place.full_name

        if tweet.created_at:
			tweet_dict['created-at'] = tweet.created_at.strftime("%Y-%m-%d %H:%M:%S")

        print tweet.user.name
        
        m = Message()
        m.set_body("This message contains text, coordinate")
        #"category":{"data_type": "String_list","string_value":[ht['text'] for ht in tweet.entities['hashtags']]}
        m.message_attributes = {"text":{"data_type": "String","string_value":tweet.text}, "id":{"data_type": "String","string_value":tweet.id},"coordinates":{"data_type": "String","string_value":tweet.coordinates['coordinates']}}
        my_queue.write(m)

        rs = my_queue.get_messages(message_attributes=['text','coordinates'])
        
        if rs:
            text_str=rs[0].message_attributes['text']['string_value']
            print text_str
            coord_str=rs[0].message_attributes['coordinates']['string_value']
            #category_str=rs[0].message_attributes['hashtag']['string_value']
            print coord_str
            #         print longitude_str
            #         print category_str
            
            response = alchemyapi.sentiment('text', text_str)
            #         print response
            my_queue.delete_message(rs[0])
            #if response['status']!="ERROR" and response["docSentiment"]["type"]!='neutral' :
            if response['status']!="ERROR" and response["docSentiment"]["type"]:
                print "sasd"
                # for item in response:
                #     print item
                try:
                    sentiment=response["docSentiment"]["type"]
                except:
                    pass
                try:
                    sentiment_score=response["docSentiment"]["score"]
                except:
                    pass
                #             print response
                #             print type(str(sentiment))
                print "Sentiment: ",sentiment
                final_str=str(sentiment)+"#"+coord_str+"#"+str(sentiment_score)
                #             print final_str
                #             js = {}
                #             js['sentiment'] = str(sentiment)
                #             js['latitude'] = latitude_str
                #             js['longitude'] = longitude_str
                #             json_str="{\"sentiment\":\""+str(sentiment)+"\",\"latitude\":\""+latitude_str+"\",\"longitude\":\""+longitude_str+"\"}"
                sns.publish(topic,final_str,subject)
                tweet_dict['text_status'] = str(response["docSentiment"]["type"])
                es.index(index = 'twitter', doc_type = 'tweets', id = tweet.id, body = tweet_dict)
                time.sleep(10)
                print "=====", counter, "===="
                counter += len(tweets)
