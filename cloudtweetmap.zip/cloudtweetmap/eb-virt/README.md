# AWS-tweetmap

# Welcome to Cloud Computing & Big Data Assignment 1

eb-flask includes the web application we created and was already deployed on EBS.

tweetToES.py was ran on an EC2 instance to download the tweets from Twitter API and upload onto the Elasticsearch.

elasticsearch.yml is the configuration file for the elasticsearch.

The url for our web application is: http://twittmap-final.89svbyfw4e.us-west-2.elasticbeanstalk.com/
